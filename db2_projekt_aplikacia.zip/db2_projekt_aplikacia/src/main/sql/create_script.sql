

drop table if exists customers cascade;
create table customers
(
    id serial primary key,
    first_name varchar,
    last_name varchar,
    e_mail varchar,
    birth varchar
);



drop table if exists coupons cascade;
create table coupons
(
    id serial primary key,
    discount int,
    code varchar UNIQUE,
    customer_id integer references customers on delete cascade,
    used boolean
);

drop table if exists orders cascade;
create table orders
(
    id serial primary key,
    order_time timestamp,
    customer_id integer references customers on delete cascade,
    coupon_id integer references coupons on delete cascade,     
    closed boolean
);

drop table if exists prices cascade;
create table prices
(
    id serial primary key,
    type varchar,
    price int
    
);

drop table if exists halls cascade;
create table halls
(
    id serial primary key,
    hall_number int,
    seat_count int
    
);

drop table if exists genres cascade;
create table genres
(
    id serial primary key,
    movie_type varchar
);



drop table if exists movies cascade;
create table movies
(
    id serial primary key,
    title varchar,
    age_limit int,
    release_date int
    
);

drop table if exists moviegenres cascade;
create table moviegenres
(
    movie_id int references movies on delete cascade,
    genre_id int references genres on delete cascade
);

drop table if exists screenings cascade;
create table screenings
(
    id serial primary key,
    start_time timestamp,
    end_time timestamp,
    hall_id integer references halls on delete cascade,
    movie_id integer references movies on delete cascade
);

drop table if exists tickets cascade;
create table tickets
(
    -- plans
    id serial primary key,
    order_id integer references orders on delete cascade,
    price_id integer references prices on delete cascade,
    screening_id integer references screenings on delete cascade,
    seat_number int,
    row_number int-- postpay, prepay
    
);

