

drop table if exists first_names cascade;
create table first_names
(
    first_name varchar
);

insert into first_names (first_name)
values	('James'), ('Willie'), ('Chad'), ('Zachary'), ('Mathew'),
	('John'), ('Ralph'), ('Jacob'), ('Corey'), ('Tyrone'),
	('Robert'), ('Lawrence'), ('Lee'), ('Herman'), ('Darren'),
	('Michael'), ('Nicholas'), ('Melvin'), ('Maurice'), ('Lonnie'),
	('William'), ('Roy'), ('Alfred'), ('Vernon'), ('Lance'),
	('David'), ('Benjamin'), ('Kyle'), ('Roberto'), ('Cody');

-- last names

drop table if exists last_names cascade;
create table last_names
(
    last_name varchar
);

insert into last_names (last_name)
values	('Smith'), ('Jones'), ('Taylor'), ('Williams'), ('Brown'),
	('Davies'), ('Evans'), ('Wilson'), ('Thomas'), ('Roberts'),
	('Johnson'), ('Lewis'), ('Walker'), ('Robinson'), ('Wood'),
	('Thompson'), ('White'), ('Watson'), ('Jackson'), ('Wright'),
	('Green'), ('Harris'), ('Cooper'), ('King'), ('Lee'),
	('Martin'), ('Clarke'), ('James'), ('Morgan'), ('Hughes'),
	('Edwards'), ('Hill'), ('Moore'), ('Clark'), ('Harrison'),
	('Scott'), ('Young'), ('Morris'), ('Hall'), ('Ward'),
	('Turner'), ('Carter'), ('Phillips'), ('Mitchell'), ('Patel'),
	('Adams'), ('Campbell'), ('Anderson'), ('Allen'), ('Cook');

-- street names

INSERT INTO genres (id, movie_type) VALUES
	(1, 'horror'), (2, 'comedy'), (3, 'fantasy'),
	(4, 'sci-fi'), (5, 'drama'), (6, 'thriller'),
	(7, 'action'), (8, 'dokumentary');

create or replace function random_first_name() returns varchar language sql as
$$
select first_name from first_names tablesample system_rows(10) order by random() limit 1
$$;

create or replace function random_last_name() returns varchar language sql as
$$
select last_name from last_names tablesample system_rows(10) order by random() limit 1
$$;

insert into customers (first_name, last_name, e_mail, birth)
select	random_first_name(),
        random_last_name(),
        random_last_name() || '@' || 'jmail.com',
       (current_date - '15 years'::interval) +
        trunc(random() * 365) * '1 day'::interval +
        trunc(random() * 14) * '1 year'::interval  as birth -- TODO: lepsie
        
from generate_series(1, 10000) as seq(i);

create or replace function randtext() returns text language sql as $$
SELECT array_to_string(ARRAY(SELECT chr((65 + round(random() * 25)) :: integer) 
FROM generate_series(1,6)), '') $$;


CREATE or replace FUNCTION make_uid() RETURNS text AS $$
DECLARE
    new_code text;
    done bool;
BEGIN
    done := false;
    WHILE NOT done LOOP
        new_code := randtext();
        done := NOT exists(SELECT 1 FROM coupons WHERE code=new_code);
    END LOOP;
    RETURN new_code;
END;
$$ LANGUAGE PLPGSQL VOLATILE;

create or replace function random_customer() returns integer language sql as $$
select id from customers order by random() limit 1
$$;


INSERT INTO coupons(discount, code, used) VALUES
    (20, '1234', false), (50, '5748', false), (10, '7574', false), (30, '5350', false), (20, '2722', false);

INSERT INTO coupons (discount, code, customer_id, used)
SELECT floor(random()*10+1)*10 as discount,
        make_uid() as code,
        random_customer() as customer_id,
        false as used
from generate_series(1,10000) as seq(i);




INSERT INTO halls(id, hall_number, seat_count) VALUES
    (1, 1, 60), (2, 2, 17), (3, 3, 30), (4, 4, 40), (5, 5, 10);

INSERT INTO movies (title, age_limit, release_date) VALUES 
    ('Dumbo', 6,2019), ('Jumanji',12,2016), ('Sharknado',99,2008), ('Avengers: End Game',16,2019), ('Bruno',18,2006),
	('Borat',18,2008), ('Aquaman',12,2018), ('Interstellar',16,2014), ('Thomas the train',6,2009), ('Bird Box',18,2018);




create or replace function randtextmovie() returns text language sql as $$
SELECT array_to_string(ARRAY(SELECT chr((65 + round(random() * 25)) :: integer) 
FROM generate_series(1,8)), '') $$;



insert into movies (title, age_limit, release_date)
    select randtextmovie() as title,
            floor(random()*10)+10 as age_limit,
            floor(random()*10)+2010 as realease_date
    from generate_series(1,100) as seq(i);


create or replace function random_genre() returns integer language sql as $$
select id from genres order by random() limit 1
$$;


create or replace function random_movie() returns integer language sql as $$
select id from movies order by random() limit 1
$$;

INSERT INTO moviegenres (genre_id, movie_id) 
	select random_genre() as genre_id,
                random_movie() as movie_id
        from generate_series(1,5000) as seq(i);


insert into screenings (start_time, end_time, hall_id, movie_id)
        select timestamp '2018-12-06 20:00:00' +
            random() * (timestamp '2019-09-20 20:00:00' -
            timestamp '2019-01-10 10:00:00') as start_time,
             
            null as end_time,

            floor(random()*5)+1 as hall_id,

            random_movie() as movie_id

        from generate_series(1,2000) as seq(i);


UPDATE screenings as s
SET end_time = (SELECT (random()*(timestamp '2019-01-10 11:30:00' - timestamp '2019-01-10 10:00:00'))+ start_time 
                    FROM screenings as s2
                     WHERE s.id = s2.id)
WHERE end_time IS NULL;


INSERT INTO orders (order_time, customer_id, coupon_id, closed) VALUES (timestamp '2019-04-10 20:00:00', 1,  null, true);

INSERT INTO orders (order_time, customer_id, coupon_id, closed)
    select timestamp '2018-10-10 20:00:00' +
            random() * (timestamp '2019-12-20 20:00:00' -
            timestamp '2019-01-10 10:00:00') as order_time,
            floor(random()*10)+1 as customer_id,
            null as coupon_id,
            true as closed
    from generate_series(1, 5000) as seq(i);
                   

INSERT INTO prices (type, price) VALUES 
	('adult', 7), ('kid', 4), ('senior', 4), ('student', 5) ; 








create or replace function random_order() returns integer language sql as $$
select id from orders order by random() limit 1
$$;

create or replace function random_price() returns integer language sql as $$
select id from prices order by random() limit 1
$$;

create or replace function random_screening() returns integer language sql as $$
select id from screenings order by random() limit 1
$$;




INSERT INTO tickets (order_id, price_id, screening_id, seat_number, row_number)
     select random_order() as order_id,
            random_price() as price_id,
            random_screening() as screening_id,
            floor(random()*20+1) as seat_number,
            floor(random()*20+1) as row_number
     from generate_series(1,10000) as seq(i);


drop table first_names, last_names;
drop function make_uid(), random_movie();