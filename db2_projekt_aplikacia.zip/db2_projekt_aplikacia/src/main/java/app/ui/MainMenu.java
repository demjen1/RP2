package app.ui;

import app.ex.CommonException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormatSymbols;
import java.time.LocalTime;
import static java.time.temporal.TemporalQueries.localDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;
import app.DbContext;
import app.ex.OutOfSeatsException;
import app.rdg.Coupon;
import app.rdg.CouponFinder;
import app.rdg.Customer;
import app.rdg.CustomerFinder;
import app.rdg.MonthIncome;
import app.rdg.Movie;
import app.rdg.MovieFinder;
import app.rdg.MovieGenre;
import app.rdg.Order;
import app.rdg.OrderFinder;
import app.rdg.Price;
import app.rdg.PriceFinder;
import app.rdg.Screening;
import app.rdg.ScreeningFinder;
import app.rdg.MoviesOfMonth;
import static app.rdg.MoviesOfMonth.getMovieGenres;
import app.rdg.Ticket;
import app.ts.OrderHandler;
import com.sun.xml.internal.ws.util.StringUtils;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.postgresql.util.PSQLException;


/**
 *
 * @author David Demjen
 * cast kodu je na zaklade vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class MainMenu extends Menu {

    @Override
    public void print() {
        
        
        
        System.out.println("*********************************");
        System.out.println("* 1. list all the customers     *");
        System.out.println("* 2. show a customer            *");
        System.out.println("* 3. add a customer             *");
        System.out.println("* 4. edit a customer            *");
        System.out.println("* 5. delete a customer          *");
        System.out.println("* 6. orders                     *");
        System.out.println("* 7. statistics                 *");
        System.out.println("* 8. exit                       *");
        System.out.println("* 9. movies                     *");
        System.out.println("* 10. show a screening          *");
        System.out.println("* 11. add a screening           *");
        System.out.println("* 12. delete a screening        *");
        System.out.println("* 13. show coupons              *");
        System.out.println("* 14. update coupon             *");
        System.out.println("* 15. delete a coupon           *");
        System.out.println("* 16. add a coupon              *");
        
        
        System.out.println("*********************************");
    }

    @Override
    public void handle(String option) {
        try {
            switch (option) {
                case "1":   listAllCustomers(); break;
                case "2":   showACustomer(); break;
                case "3":   addACustomer(); break;
                case "4":   editACustomer(); break;
                case "5":   deleteACustomer(); break;
                case "6":   orders(); break;
                case "7":   statistics(); break;
                case "8":   exit(); break;
                case "9":   movies(); break;
                case "10":   showAScreening(); break;
                case "11":   addAScreening(); break;
                case "12":   deleteScreening(); break;
                case "13":   showCoupons(); break;
                case "14":   updateCoupon(); break;
                case "15":   deleteCoupon(); break;
                case "16":   addCoupon(); break;
                
                default:    System.out.println("Unknown option"); break;
            }
        } catch(SQLException | IOException e) {
            throw new RuntimeException(e);
        }

    }
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////COUPONS
    private void addCoupon() throws IOException, SQLException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("customer id: ");
        Integer customerId = getCustomerID();
        System.out.println("Coupon code: ");
        String code = br.readLine();
        System.out.println("Discount (0-100%): ");
        String discount = br.readLine();
        boolean used = false;
        
        Coupon coup = new Coupon();
        coup.setCode(code);
        coup.setCustomer(customerId);
        coup.setDiscount(Integer.parseInt(discount));
        coup.setUsed(used);
        coup.insertCoupon();
    }

    private void deleteCoupon() throws SQLException, IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String id = br.readLine();
        if(!isInteger(id)){
            badOption();
            return;
        }
        Coupon coup = CouponFinder.getInstance().findById(Integer.parseInt(id));
        if(coup == null){
            badOption();
            return;
        }
        coup.delete();
    }
    
    private void showCoupons() throws IOException, SQLException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Customer id: ");
        String cid = br.readLine();
        if(!isInteger(cid)){
            badOption();
            return;
        }
        List<Coupon> list = CouponFinder.getInstance().findAllById(Integer.parseInt(cid));
        for(Coupon coup : list){
            coup.print();}
        
    }
    
    private void updateCoupon() throws IOException, SQLException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Coupon id: ");
        String id = br.readLine();
        if(!isInteger(id)){
            badOption();
            return;
        }
        Coupon coup = CouponFinder.getInstance().findById(Integer.parseInt(id));
        if(coup == null){
            badOption();
            return;
        }
        
        
        System.out.println("customer id: ");
        Integer customerId = getCustomerID();
        System.out.println("Coupon code: ");
        String code = br.readLine();
        System.out.println("Discount (0-100%): ");
        String discount = br.readLine();
        System.out.println("Used(1-0): ");
        String used = br.readLine();
        
        coup.setCode(code);
        coup.setCustomer(customerId);
        coup.setDiscount(Integer.parseInt(discount));
        if(used.equals("1")){
            coup.setUsed(true);}
        else{
            coup.setUsed(false);
        }
        coup.update();
        
    }
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////MOVIE
    
    private void movies() throws IOException, SQLException{
        System.out.println("*********************************");
            System.out.println("* 1. show a movie     *");
            System.out.println("* 2. delete movie            *");
            System.out.println("* 3. update movie             *");
            System.out.println("* 4. add movie            *");
            System.out.println("* 5. exit                       *");
            System.out.println("*********************************");

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String line = br.readLine();
            handleMovie(line);
    }
    
    private void badOption(){
        System.out.println("Unknown option");
    }
   
    private void handleMovie(String line) throws IOException, SQLException{
        switch (line) {
                case "1":   showMovie(); break;
                case "2":   deleteMovie(); break;
                case "3":   updateMovie(); break;
                case "4":   addMovie(); break;
                case "5":   exit();break;
                default:    System.out.println("Unknown option"); break;
        }
    }
    
    private void addMovie() throws SQLException, IOException{
        Movie order = new Movie();
        
        System.out.println("Title: ");
        BufferedReader title = new BufferedReader(new InputStreamReader(System.in));
        order.setTitle(title.readLine());
        
        System.out.println("Age limit: ");
        BufferedReader agelim = new BufferedReader(new InputStreamReader(System.in));
        order.setAgeLimit(Integer.parseInt(agelim.readLine()));
        
        System.out.println("Release_date: ");
        BufferedReader reldate = new BufferedReader(new InputStreamReader(System.in));
        order.setRelease(Integer.parseInt(reldate.readLine()));
        
        order.insert();
        
        while(true){
            System.out.println("1. Add genre ");
            System.out.println("2. delete genre ");
            System.out.println("3. Thats all");
            BufferedReader deladd = new BufferedReader(new InputStreamReader(System.in));
            if(deladd.readLine().equals("1")){
                System.out.println("Genre id: ");
                BufferedReader gen = new BufferedReader(new InputStreamReader(System.in));
                MovieGenre movgen = new MovieGenre();
                movgen.setGenre(Integer.parseInt(gen.readLine()));
                movgen.setMovie(order.getId());
                movgen.insert();
            }
            else if(deladd.readLine().equals("2")){
                System.out.println("Genre id: ");
                BufferedReader gen = new BufferedReader(new InputStreamReader(System.in));
                MovieGenre movgen = new MovieGenre();
                movgen.setGenre(Integer.parseInt(gen.readLine()));
                movgen.setMovie(order.getId());
                movgen.delete();
            }
            else{
                break;
            }
        }
    }
    
    
    private void showMovie() throws IOException, SQLException{
        for(Movie movie : MovieFinder.getInstance().findAll()){
            movie.print();
        }
         System.out.println("Which one?");
         BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
       
        int orderId = Integer.parseInt(br.readLine());

        Movie movie = MovieFinder.getInstance().findById(orderId);
        MoviePrinter.getInstance().print(movie);
        System.out.println("Screenings: ");
         
        listScreenings(movie);
    }
    
    private void deleteMovie() throws SQLException, IOException {
        for(Movie movie : MovieFinder.getInstance().findAll()){
            movie.print();
        }
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Which one to delete?");
        int orderId = Integer.parseInt(br.readLine());

        Movie order = MovieFinder.getInstance().findById(orderId);
        
        if (order == null) {
            System.out.println("No such movie exists");
        } else {
            order.delete();
            System.out.println("The movie has been successfully deleted");
        }
    }
    
    private void updateMovie() throws SQLException, IOException{
        for(Movie movie : MovieFinder.getInstance().findAll()){
            movie.print();
        }
        System.out.println("Which one to edit?");
       
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
         int orderId = Integer.parseInt(br.readLine());

        Movie order = MovieFinder.getInstance().findById(orderId);
        
        System.out.println("Title: ");
        BufferedReader title = new BufferedReader(new InputStreamReader(System.in));
        order.setTitle(title.readLine());
        
        System.out.println("Age limit: ");
        BufferedReader agelim = new BufferedReader(new InputStreamReader(System.in));
        order.setAgeLimit(Integer.parseInt(agelim.readLine()));
        
        System.out.println("Release_date: ");
        BufferedReader reldate = new BufferedReader(new InputStreamReader(System.in));
        order.setRelease(Integer.parseInt(reldate.readLine()));
        
        order.update();
        while(true){
            System.out.println("1. Add genre ");
            System.out.println("2. delete genre ");
            System.out.println("3. Thats all");
            BufferedReader deladd = new BufferedReader(new InputStreamReader(System.in));
            if(deladd.readLine().equals("1")){
                System.out.println("Genre id: ");
                BufferedReader gen = new BufferedReader(new InputStreamReader(System.in));
                MovieGenre movgen = new MovieGenre();
                movgen.setGenre(Integer.parseInt(gen.readLine()));
                movgen.setMovie(order.getId());
                movgen.insert();
            }
            else if(deladd.readLine().equals("2")){
                System.out.println("Genre id: ");
                BufferedReader gen = new BufferedReader(new InputStreamReader(System.in));
                MovieGenre movgen = new MovieGenre();
                movgen.setGenre(Integer.parseInt(gen.readLine()));
                movgen.setMovie(order.getId());
                movgen.delete();
            }
            else{
                break;
            }
        }
    }
    
    public static void movieList() throws SQLException{
        
        for (Movie movie : MovieFinder.getInstance().findAll()) {
            movie.print();
        }
    }
    
    
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////ORDER
    
    private void orders() throws IOException, SQLException {
        System.out.println("*********************************");
        System.out.println("* 1. make order     *");
        System.out.println("* 2. delete order            *");
        System.out.println("* 3. update order             *");
        System.out.println("* 4. my orders            *");
        
        System.out.println("* 5. exit                       *");
        System.out.println("*********************************");
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line = br.readLine();
        handleOrder(line);
    }
    
    private void handleOrder(String line) throws IOException, SQLException{
        switch (line) {
                case "1":   {
                                try {
                                    OrderHandler.order2();
                                } catch (OutOfSeatsException ex) {
                                    System.out.print("No more free seats left!");
                                } catch (CommonException ex) {
                                    System.out.print(ex);
                                }
                                catch(PSQLException e){
                                    System.out.print(e);
                                }
                            }
                                break;
                case "2":   deleteOrder(); break;
                case "3":   updateOrder(); break;
                case "4":   myOrders(true); break;
                case "5":   exit();break;
                default:    System.out.println("Unknown option"); break;
        }
    }
    
    private void deleteOrder() throws SQLException, IOException {
        myOrders(false);
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Which one to delete?");
        int orderId = Integer.parseInt(br.readLine());

       Order order = OrderFinder.getInstance().findById(orderId);
        
        if (order == null) {
            System.out.println("No such customer exists");
        } else {
            order.delete();
            System.out.println("The order has been successfully deleted");
        }
    }
    
    private void updateOrder() throws SQLException, IOException{
        myOrders(false);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Which one to update?");
        String orderStr = br.readLine();
        if(!isInteger(orderStr)){
            System.out.println("Wrong id!");
            return;
        }
        Integer orderId = Integer.parseInt(orderStr);
        Order order = OrderFinder.getInstance().findById(orderId);
        if(order == null){
            System.out.println("Wrong id!");
            return;
        }
        
        BufferedReader what = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Delete or Buy a ticket?");
        System.out.println("1 to buy a ticket");
        System.out.println("2 to delete a ticket");
        String whatStr = what.readLine();
        if(!isInteger(whatStr)){
            System.out.println("No such option");
            return;
        }
        if(Integer.parseInt(whatStr) == 1){
            Ticket tick = buyTicket();
            if(!OrderHandler.controlTicketOutOfTime(tick)){
                System.out.println("No seats left there");
                return;
            }
            System.out.println("To confirm type 'y' else type anything");
            BufferedReader confirm = new BufferedReader(new InputStreamReader(System.in));
            if(confirm.readLine().equals("y")){
                if(tick != null){
                    tick.setOrder(orderId);
                    tick.insertTicket();
                }
                
            }
            else{
                System.out.println("Shame!");
            }
        }
        
        
    }
    
    private Ticket buyTicket() throws SQLException, IOException{
        BufferedReader ord = new BufferedReader(new InputStreamReader(System.in));
        
        Ticket out = new Ticket();
        System.out.println("Price type: ");
        out.setPrice(Integer.parseInt(ord.readLine()));
        
        System.out.println("Screening: ");
        out.setScreening(Integer.parseInt(ord.readLine()));
        
        System.out.println("Row: ");
        out.setrow(Integer.parseInt(ord.readLine()));
        
        
        System.out.println("Seat: ");
        out.setseat(Integer.parseInt(ord.readLine()));
        
        
        return out;
                
    }
    
    private void myOrders(boolean full) throws SQLException, IOException{
        System.out.println("Type your id: ");
        Integer customerId = getCustomerID();
        if(customerId == null){
            return;
        }
        Customer customer = CustomerFinder.getInstance().findById(customerId);
        if(customer == null){
            System.out.println("Wrong id!");
            return;
        }
        List<Order> tmp = OrderFinder.getInstance().findAllById(customerId);
        if(tmp.size() > 0){
            for(int i = 0; i < tmp.size(); i++){
                tmp.get(i).print();
            }
        
            if(full){
                System.out.println("Type order id: ");
                BufferedReader ord = new BufferedReader(new InputStreamReader(System.in));
                
                String ordd = ord.readLine();
                if(!isInteger(ordd)){
                    System.out.println("Wrong id!");
                    return;
                }
                Order order = OrderFinder.getInstance().findById(Integer.parseInt(ordd));
                
                if(order == null){
                    System.out.println("Wrong id!");
                    return;
                }
                OrderPrinter.getInstance().print(order);
                }
        }
        else{
            System.out.println("No orders");
        }
        }
        
    
    
    public static Order makeOrder2() throws IOException, SQLException, OutOfSeatsException, CommonException{
        
        List<Ticket> tickets = new ArrayList<>();
        BufferedReader who = new BufferedReader(new InputStreamReader(System.in));
        Integer customerId = getCustomerID();
        System.out.println("Which movie do you want?");
        String movieStr = who.readLine();
        Movie movie = null;
        if(isInteger(movieStr)){
            movie = MovieFinder.getInstance().findById(Integer.parseInt(movieStr));
        }
                
        if(movie == null){
            System.out.println("No such movie");
        }
        
        
        System.out.println("Which screening do you choose?");
        System.out.println();
        String screenStr = who.readLine();
        
        System.out.println("Select the type: ");
        String prce = who.readLine();
        
        
        int x = ticketNumber();
        
        
        
        System.out.println("Want to add coupon? (y/n)");
        boolean coup = false;
        String ifcoup = who.readLine();
        String coupcode = "";
        if(ifcoup.equals("y")){
            coup = true;
            System.out.println("Add coupon code: ");
            coupcode = who.readLine();
        }
        Price prc = null;
        if(isInteger(prce)){
            prc = PriceFinder.getInstance().findById(Integer.parseInt(prce));
        }
        Integer scrns = null;
        if(isInteger(screenStr)){
            scrns = Integer.parseInt(screenStr);
        }
        Screening screening = ScreeningFinder.getInstance().findById(scrns);
        
        if(screening.getStart().getTime() - System.currentTimeMillis() < 2400000){
            System.out.print("Cant buy tickets on this screening");
            return null;
        }
        
        
        
        Order order = new Order();
        try{
            OrderHandler.setOrder(order, coup, customerId, coupcode);
        }
        catch(CommonException e){
            System.out.print(e);
        }
        try{
            OrderHandler.reserveTickets(x, tickets, screening, prc, order);
        }
        catch(OutOfSeatsException e){
            System.out.println("Couldnt reserve seats!");
            throw e;
        }
        
        System.out.println("Confirm? (y)");
        String conf = who.readLine();
        if(conf.equals("y")){
            return order;
        }
        return null;
        
    }
    
    /*
    public static void makeOrder() throws IOException, SQLException, OutOfSeatsException, CommonException{
        
        long time = 0;
        Timestamp start = new Timestamp(System.currentTimeMillis());
    
        List<Ticket> tickets = new ArrayList<>();
        //System.out.println("Type your id: ");
        BufferedReader who = new BufferedReader(new InputStreamReader(System.in));
        Integer customerId = getCustomerID();
        if(customerId == null){
            System.out.println("Wrong id!");
            return;
        }
        Customer customer = CustomerFinder.getInstance().findById(customerId);
        
        if (customer == null) {
            System.out.println("No such customer exists");
        } else {
            System.out.println("Hello " + customer.getFirstName());
            System.out.println();
            while(true){
        
                /////////////////////////////////////////////////////////////////////////////////////////MOVIE
                
                movieList();
                
                System.out.println("Which movie do you want?");
                System.out.println();
                BufferedReader which = new BufferedReader(new InputStreamReader(System.in));
                
                
                String movieStr = which.readLine();
                Movie movie = null;
                if(isInteger(movieStr)){
                    movie = MovieFinder.getInstance().findById(Integer.parseInt(movieStr));
                }
                
                if(movie == null){
                    System.out.println("No such movie");
                }
                else{
                    /////////////////////////////////////////////////////////////////////////////////////////SCREENING
                    Timestamp current = new Timestamp(System.currentTimeMillis());
                    List<Integer> screens = listScreenings(movie,current);
                    if(screens.size()> 0){
                        Screening screening;
                        while(true){
                            System.out.println("Which screening do you choose?");
                            System.out.println();
                            BufferedReader wscreening = new BufferedReader(new InputStreamReader(System.in));
                            
                            String screenStr = wscreening.readLine();
                            Integer scrns = null;
                            if(isInteger(screenStr)){
                                scrns = Integer.parseInt(screenStr);
                            }
                            
                            
                            if(screens.contains(scrns)){
                                screening = ScreeningFinder.getInstance().findById(scrns);
                        
                                break;
                            }
                            else{
                              System.out.println("No such screening for that movie!")  ;
                              screening = null;
                            }
                        }
                        
                        
                        /////////////////////////////////////////////////////////////////////////////////////////TYPE
                        Price prc = null;
                        while(true){
                            System.out.println("Select the type: ");
                            listPrices();
                            BufferedReader price = new BufferedReader(new InputStreamReader(System.in));
                            String prce = price.readLine();
                            if(isInteger(prce)){
                                prc = PriceFinder.getInstance().findById(Integer.parseInt(prce));
                            }
                            
                            if(prc == null){
                                System.out.println("No such type!");
                            }
                            else{
                                break;
                            }
                        }
                        /////////////////////////////////////////////////////////////////////////////////////////NUMBER OF TCKTS
                            int x = ticketNumber();
                            
                            /////////////////////////////////////////////////////////////////////////////////////////TCKT RESERVATION
                            try{
                                OrderHandler.reserveTickets(x, tickets, screening, prc);
                            }
                            catch(OutOfSeatsException e){
                                System.out.println("Couldnt reserve seats!");
                                throw e;
                            }
                            System.out.println("Do you want more tickets? y/n");
                            BufferedReader more = new BufferedReader(new InputStreamReader(System.in));
                            if(more.readLine().equals("y")){
                                continue;
                            }
                            else{
                                break;
                            }
                        
                    }
                    else{
                        System.out.println("Another movie? y/n");
                        BufferedReader anot = new BufferedReader(new InputStreamReader(System.in));
                        if(anot.readLine().equals("y")){
                            continue;
                        }
                        else{
                            break;
                        }
                }
            }////
            
            
            }
            String code = null;
            while(true){
                System.out.println("Want to use coupon? (y)");

                String coupon = who.readLine();
                
                if(coupon.equals("y")){
                    System.out.println("Add the code: ");
                    code = who.readLine();
                    Coupon tmp = CouponFinder.getInstance().findByCode(code);
                    if(tmp == null){
                        System.out.println("The coupon doesnt exist");
                    }
                    else if(tmp.getUsed()){
                        System.out.println("The coupon was already used");
                    }
                    else{
                        break;
                    }
                }
                else{
                    break;
                }
            }
            
            confirmOrder(tickets, start, customer, code);
        }
        
    }
    
    
    
    private static void confirmOrder(List<Ticket> tickets, Timestamp start, Customer customer, String code) throws SQLException, IOException, CommonException, OutOfSeatsException{
        System.out.println("Your tickets: ");
        System.out.println(tickets);
            for(int i = 0; i < tickets.size(); i++){
                tickets.get(i).print();
            }
            
            System.out.println("Confirm your order (y/n)");
            BufferedReader confirm = new BufferedReader(new InputStreamReader(System.in));
            if(confirm.readLine().equals("y")){
                Timestamp present = new Timestamp(System.currentTimeMillis());
                long time = present.getTime()-start.getTime();
                if(time <= 600000){
                    List<Ticket> finish = OrderHandler.finishOrder(customer.getId(), tickets, code);
                    if(finish.size() == 0){
                        System.out.println("Order confirmed!");
                        
                    }
                    else if(finish.size() == tickets.size()){
                        System.out.println("None of the choosen tickets could been reserved ");
                    
                    }
                    else{
                        System.out.println("Couldnt reserve these tickets: ");
                        for(int i = 0; i < finish.size();i++){
                            finish.get(i).print();
                        }
                    }
                    return;
                }
                else{
                    for(int ti = 0; ti< tickets.size(); ti++){
                        tickets.get(ti).delete();
                    }
                    
                    System.out.println("Time is up! (you have 10 minutes to order)");
                    System.out.println("Want to order again? (y/n)");
                    BufferedReader conf = new BufferedReader(new InputStreamReader(System.in));
                    if(conf.readLine().equals("y")){
                        start = new Timestamp(System.currentTimeMillis());
    
                        OrderHandler.order();
                    }
                    else{
                        return;
                    }
                }
            
            }
            else{
                for(int ti = 0; ti< tickets.size(); ti++){
                        tickets.get(ti).delete();
                   }
                return;
               }
    }*/
    
    public static int ticketNumber() throws IOException{
                            
        System.out.println("How many of it?");
        BufferedReader howmany = new BufferedReader(new InputStreamReader(System.in));
        String ticketcount = howmany.readLine();
                                
        try{
            int x = Integer.parseInt(ticketcount);
            return x;
            }catch (NumberFormatException e){
                System.out.println("Not a number");
                ticketNumber();

            }
        return 0;
                            
    }
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////SCREENINGS, PRICES
    public static void listPrices() throws SQLException{
        List<Price> tmp = PriceFinder.getInstance().findAll();
        for(int i = 0; i < tmp.size(); i++){
            tmp.get(i).print();
        }
    }
    
    private boolean listScreenings(Movie movie) throws SQLException{
        
        Timestamp current = new Timestamp(System.currentTimeMillis());
        
        List<Screening> tmp = ScreeningFinder.getInstance().findForMovie(movie, current);
        if(tmp.size()<1){
            System.out.println("Sorry, no screenings for this one");
            return false;
        }
        for(int i = 0; i < tmp.size(); i++){
            tmp.get(i).print();
        }
        return true;
    }
    
    public static List<Integer> listScreenings(Movie movie, Timestamp current) throws SQLException{
        
        List<Integer> out = new ArrayList<Integer>();
        
        List<Screening> tmp = ScreeningFinder.getInstance().findForMovie(movie, current);
        if(tmp.size()<1){
            System.out.println("Sorry, no screenings for this one");
            
        }
        for(int i = 0; i < tmp.size(); i++){
            tmp.get(i).print();
            out.add(tmp.get(i).getId());
        }
        return out;
    }
    
    private void showAScreening() throws IOException, SQLException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Add id: ");
        String isStr = br.readLine();
        if(!isInteger(isStr)){
            badOption();
            return;
            
        }
        Screening scrn = ScreeningFinder.getInstance().findById(Integer.parseInt(isStr));
        if(scrn == null){
            System.out.println("No such screening");
            return;
        }
        scrn.print();
        
    }
    
    private void addAScreening() throws IOException, SQLException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Add movie id: ");
        String movieIDstr = br.readLine();
        if(!isInteger(movieIDstr)){
            badOption();
            return;
        }
        Movie movie = MovieFinder.getInstance().findById(Integer.parseInt(movieIDstr));
        if(movie == null){
            System.out.println("No such movie");
            return;
        }
        
        System.out.println("Start time (YYYY-MM-DD hh:mm:ss): ");
        String startStr = br.readLine();
        Timestamp startTS = Timestamp.valueOf(startStr);
        
        System.out.println("End time (YYYY-MM-DD hh:mm:ss): ");
        String endStr = br.readLine();
        Timestamp endTS = Timestamp.valueOf(endStr);
        System.out.println("Hall number: ");
        String hallStr = br.readLine();
        if(!isInteger(hallStr)){
            System.out.println("wrong number");
            return;
        }
        
        Screening scrn = new Screening();
        scrn.setMovie(movie.getId());
        scrn.setStart(startTS);
        scrn.setEnd(endTS);
        scrn.setHall(Integer.parseInt(hallStr));
        
        scrn.insert();
        System.out.println("ok");
    }
    
    private void deleteScreening() throws IOException, SQLException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String idStr = br.readLine();
        if(!isInteger(idStr)){
            badOption();
            return;
        }
        
        Screening scrn = ScreeningFinder.getInstance().findById(Integer.parseInt(idStr));
        if(scrn != null){
            scrn.delete();
            System.out.println("ok");
        }
        else{
            badOption();
            return;
        }
        
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////STATISTICS
    
    private void statistics() throws IOException, SQLException{
        
        System.out.println("*********************************");
        System.out.println("* 1. Movies of the months     *");
        System.out.println("* 2. Income for last 2 months *");
        
        System.out.println("* 5. exit                       *");
        System.out.println("*********************************");
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line = br.readLine();
        handleStat(line);
    }
    
    private void handleStat(String line) throws SQLException{
        
        switch (line) {
                case "1":   printMoM(); break;
                case "2":   printMI(); break;
                case "5":   exit();break;
                default:    System.out.println("Unknown option"); break;
        }
        
        
    }
    
    private void printMI() throws SQLException{
        HashMap<String, Integer[]> income = MonthIncome.getInstance().monthIncome();
        for(String gen: income.keySet()){
            System.out.print(gen + ": ");
            System.out.print(Integer.toString(income.get(gen)[0]));
            System.out.println(", " +Integer.toString(income.get(gen)[1]));;
        }
        
    }
    
    
    public String getMonth(int month) {
        return new DateFormatSymbols().getMonths()[month-1];
        }   
    
    
    
    
    
    private void printMoM() throws SQLException{
         HashMap<String, ArrayList<String>> genres = MoviesOfMonth.getMovieGenres();
        
        //JOIN moviegenres as mg ON m.id = mg.movie_id JOIN genres as g ON mg.genre_id = g.id
        
        
        //System.out.println(genres);
        
        
        Calendar localCalendar = Calendar.getInstance(TimeZone.getDefault());
        int month = localCalendar.get(Calendar.MONTH) + 1;
        
        for(int mon = 0; mon < 6; mon++ ){
            
            System.out.println("Top for " +getMonth(month) +":" );
            
            for(String gen : genres.keySet()){
                
                
                
                HashMap<String, Integer> pole = MoviesOfMonth.MoM(genres, gen, month);
                
                System.out.println(gen +": ");

                System.out.println(pole);
                System.out.println();


            }
             month--;
                if(month<1){
                    month += 12; 
                }
        }
    }
    
    
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////CUSTOMER
    
    private void listAllCustomers() throws SQLException {
        for (Customer customer : CustomerFinder.getInstance().findAll()) {
            CustomerPrinter.getInstance().print(customer);
        }
    }
    
    private void showACustomer() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
         Integer customerId = getCustomerID();
        if(customerId == null){
            return;
        }
        Customer customer = CustomerFinder.getInstance().findById(customerId);
        
        if (customer == null) {
            System.out.println("No such customer exists");
        } else {
            CustomerPrinter.getInstance().print(customer);
        }

    }

    private void addACustomer() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        Customer customer = new Customer();
        
        System.out.println("Enter first name:");
        customer.setFirstName(br.readLine());
        System.out.println("Enter last name:");
        customer.setLastName(br.readLine());
        System.out.println("Enter e-mail:");
        customer.setEmail(br.readLine());
        System.out.println("Enter Birth:");
        customer.setBirth(br.readLine());
        
        customer.insert();
        
        System.out.println("The customer has been sucessfully added");
        System.out.print("The customer's id is: ");
        System.out.println(customer.getId());
    }

    private void editACustomer() throws IOException, SQLException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        
        Integer customerId = getCustomerID();
        if(customerId == null){
            return;
        }
        Customer customer = CustomerFinder.getInstance().findById(customerId);
        
        if (customer == null) {
            System.out.println("No such customer exists");
        } else {
            CustomerPrinter.getInstance().print(customer);

            System.out.println("Enter first name:");
            customer.setFirstName(br.readLine());
            System.out.println("Enter last name:");
            customer.setLastName(br.readLine());
            System.out.println("Enter e-mail:");
            customer.setEmail(br.readLine());
            System.out.println("Enter Birth:");
            customer.setBirth(br.readLine());

            customer.update();

            System.out.println("The customer has been successfully updated");
        }
    }

    private void deleteACustomer() throws SQLException, IOException {
        
        
        Integer customerId = getCustomerID();
        if(customerId == null){
            return;
        }
        Customer customer = CustomerFinder.getInstance().findById(customerId);
        
        if (customer == null) {
            System.out.println("No such customer exists");
        } else {
            customer.delete();
            System.out.println("The customer has been successfully deleted");
        }
    }
    
    public static boolean isInteger(String s) {
        try { 
            Integer.parseInt(s); 
        } catch(NumberFormatException e) { 
            return false; 
        } catch(NullPointerException e) {
            return false;
        }
        // only got here if we didn't return false
        return true;
    }
    
    public static Integer getCustomerID() throws IOException{
       Integer ID;
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Enter a customer's id:");
        
        String cID = br.readLine();
        if(!isInteger(cID)){
            System.out.println("No such customer exists");
            return null;
        }
        else{
            ID = Integer.parseInt(cID);
        }
        
        return ID;
    }
    
}