package app.ui;

import app.rdg.Customer;


/**
 *
 * @author David Demjen
 * cast kodu je na zaklade vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class CustomerPrinter {
    
    private static final CustomerPrinter INSTANCE = new CustomerPrinter();
    
    public static CustomerPrinter getInstance() { return INSTANCE; }
    
    private CustomerPrinter() { }
        
    public void print(Customer customer) {
        if (customer == null) {
            throw new NullPointerException("customer cannot be null");
        }
        
        System.out.print("id :          ");
        System.out.println(customer.getId());
        System.out.print("first name:   ");
        System.out.println(customer.getFirstName());
        System.out.print("last name:    ");
        System.out.println(customer.getLastName());
        System.out.print("e-mail: ");
        System.out.println(customer.getEmail());
        System.out.print("Birth date:      ");
        System.out.println(customer.getBirth());
        System.out.println();
    }
}
