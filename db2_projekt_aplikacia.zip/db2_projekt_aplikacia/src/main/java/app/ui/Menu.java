package app.ui;

import app.OrderController;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Alexander Šimko
 */
public abstract class Menu {

    private boolean exit;

    public void run() throws IOException {
        exit = false;

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        OrderController ordcont = new OrderController();
        while (exit == false) {
            System.out.println();
            print();
            System.out.println();

            String line = br.readLine();
            if (line == null) {
                return;
            }

            System.out.println();
            
            //ordcont.start();
            handle(line);
        }/*
        if(exit){
            ordcont.runing = false;
            ordcont.interrupt();
        }*/
    }

    public void exit() {
        
        exit = true;
    }

    public abstract void print();

    public abstract void handle(String option);	
}