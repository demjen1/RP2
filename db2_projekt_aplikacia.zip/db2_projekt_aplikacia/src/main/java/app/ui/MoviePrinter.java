/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.ui;

import app.rdg.Movie;
import app.rdg.MovieFinder;
import app.rdg.Order;
import app.rdg.OrderFinder;
import app.rdg.PriceFinder;
import app.rdg.Ticket;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Asus
 */
public class MoviePrinter {
    private static final MoviePrinter INSTANCE = new MoviePrinter();
    
    public static MoviePrinter getInstance() { return INSTANCE; }
    
    private MoviePrinter() { }
    
    public void print(Movie order) throws SQLException {
        if (order == null) {
            throw new NullPointerException("customer cannot be null");
        }
        
        List<String> list = MovieFinder.getInstance().getGenres(order);
       
        
        
        System.out.println("== " + Integer.toString(order.getId()) + " ==");
        System.out.println("Title: " + order.getTitle());
        System.out.println("Age limit: " + Integer.toString(order.getAgeLimit()));
        System.out.println("Release date: " + order.getRelease());
        
        System.out.println();
        System.out.print("Genres: ");
        for(String tick : list){
            System.out.print(tick +" ");
        }
        System.out.println();
       
        
    }
    
}
