/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.ui;

import app.rdg.Coupon;
import app.rdg.CouponFinder;
import app.rdg.Customer;
import app.rdg.Order;
import app.rdg.OrderFinder;
import app.rdg.PriceFinder;
import app.rdg.Ticket;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Asus
 */
public class OrderPrinter {
    private static final OrderPrinter INSTANCE = new OrderPrinter();
    
    public static OrderPrinter getInstance() { return INSTANCE; }
    
    private OrderPrinter() { }
        
    public void print(Order order) throws SQLException {
        if (order == null) {
            throw new NullPointerException("customer cannot be null");
        }
        
        List<Ticket> list = OrderFinder.getInstance().findTicketsForOrder(order.getId());
        int sum = 0;
        
        
        System.out.println("== " + Integer.toString(order.getId()) + " ==");
        System.out.println("Time: " + order.getOrderTime());
        System.out.println("Customer ID: " + Integer.toString(order.getCustomer()));
        
        System.out.println();
        
        for(Ticket tick : list){
            tick.print();
            sum += PriceFinder.getInstance().findById(tick.getPrice()).getPrice();
        }
        double finalprice = sum;
        
        if(order.getCoupon() != null){
            Coupon coup = CouponFinder.getInstance().findById(order.getCoupon());
            
            double summ = sum;
            double disc = coup.getDiscount();
            finalprice = summ - (summ*(disc/100));
        }
        
        System.out.println("The full price is: " + Integer.toString((int) finalprice));
        
    }
}
