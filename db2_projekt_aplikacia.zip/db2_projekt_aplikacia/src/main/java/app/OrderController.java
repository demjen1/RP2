/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import app.rdg.Order;
import app.rdg.OrderFinder;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asus
 */
public class OrderController extends Thread{
    
    public boolean runing = true;
    
    public OrderController(){}
    
    public void run(){
        while(runing){
            
            
            
            long current_time = System.currentTimeMillis();
            List<Order> pole = new ArrayList<>();
            try {
                pole = OrderFinder.getInstance().findAllNotClosed();
            } catch (SQLException ex) {
                Logger.getLogger(OrderController.class.getName()).log(Level.SEVERE, null, ex);
            }
            for(Order order: pole){
                if(current_time - order.getOrderTime().getTime() > 600000){
                    try {
                        order.delete();
                    } catch (SQLException ex) {
                        Logger.getLogger(OrderController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
            
            try {
		Thread.sleep(10040);
		} catch (InterruptedException e) {
                    
		}
            
        }
        
        
    }
    
    
    
}
