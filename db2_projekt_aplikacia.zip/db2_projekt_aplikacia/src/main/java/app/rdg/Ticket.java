/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import app.DbContext;


/**
 *
 * @author David Demjen
 * cast kodu je na zaklade vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class Ticket extends Entity {
    
    int screening_id;
    int order_id;
    int price_id;
    int seat_number;
    int row_number;
    
    public Ticket(){
        
    }
    
    public Ticket(int scrn, int prc){
        screening_id = scrn;
        //order_id  = ordr;
        price_id = prc;
    }
    
    public void insertTicket() throws SQLException{
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("INSERT INTO tickets (order_id, price_id, screening_id, seat_number, row_number) VALUES (?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            int y = 0;
            int x = 0;
            
          
            s.setInt(1, order_id);
            s.setInt(2, price_id);
            s.setInt(3, screening_id);
            s.setInt(4, y);
            s.setInt(5, x);

            s.executeUpdate();

            try (ResultSet r = s.getGeneratedKeys()) {
                r.next();
                id = r.getInt(1);
            }
        }
    }
    
    public void insertTicketNullOrd() throws SQLException{
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("INSERT INTO tickets (order_id, price_id, screening_id, seat_number, row_number) VALUES (?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            int y = 0;
            int x = 0;
            
          
            s.setNull(1, java.sql.Types.INTEGER);
            s.setInt(2, price_id);
            s.setInt(3, screening_id);
            s.setInt(4, y);
            s.setInt(5, x);

            s.executeUpdate();

            try (ResultSet r = s.getGeneratedKeys()) {
                r.next();
                id = r.getInt(1);
            }
        }
    }
    

    public int getScreening() {
        return screening_id;
    }

    public void setScreening(int firstName) {
        this.screening_id = firstName;
    }

    public int getOrder() {
        return order_id;
    }

    public void setOrder(int order) {
        this.order_id = order;
    }

    public int getPrice() {
        return price_id;
    }

    public void setPrice(int eMail) {
        this.price_id = eMail;
    }
    
    public int getseat() {
        return seat_number;
    }

    public void setseat(int seat) {
        this.seat_number = seat;
    }
    
    public int getrow() {
        return row_number;
    }

    public void setrow(int row) {
        this.row_number = row;
    }
    
    public void delete() throws SQLException {
        if (id == null) {
            throw new IllegalStateException("id is not set");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("DELETE FROM tickets WHERE id = ?")) {
            s.setInt(1, id);

            s.executeUpdate();
        }
    }
    
    public void print() throws SQLException{
        System.out.println("=========Ticket: " + Integer.toString(id) + " ==========");
        ScreeningFinder.getInstance().findById(screening_id).print();
        
        System.out.println("Row: " + Integer.toString(row_number));
        
        System.out.println("Seat: " + Integer.toString(seat_number));
        PriceFinder.getInstance().findById(price_id).print();
        System.out.println("===============================");
        
    }
    
}
