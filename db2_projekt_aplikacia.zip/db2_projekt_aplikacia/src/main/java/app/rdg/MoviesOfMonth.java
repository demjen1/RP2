/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import app.DbContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Asus
 */
public class MoviesOfMonth {
    
    
    /**
     * 
     * @return ArrayList of all genres
     * @throws SQLException 
     */
    public static ArrayList<String> getGenres() throws SQLException{
        ArrayList<String> pole = new ArrayList<>();
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM genres")) {
            try (ResultSet r = s.executeQuery()) {
                
                while (r.next()) {
                    pole.add(r.getString("movie_type"));
                    
                }
            }
        }
        
        return pole;
    }
    
    /**
     * 
     * @return Hashmap of Genres as key and ArrayList of movies by genres as value
     * @throws SQLException 
     */
    public static HashMap<String, ArrayList<String>> getMovieGenres() throws SQLException{
        HashMap<String, ArrayList<String>> genres = new HashMap<>();
        List<String> gens = getGenres();
        for(int i = 0; i < gens.size(); i++){
            genres.put(gens.get(i), new ArrayList<>());
        }
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM movies as m JOIN moviegenres as mg ON m.id = mg.movie_id JOIN genres as g ON mg.genre_id = g.id")) {
            try (ResultSet r = s.executeQuery()) {
                
                while (r.next()) {
                    ArrayList<String> tmp = genres.get(r.getString("movie_type"));
                    tmp.add(r.getString("title"));
                    genres.put(r.getString("movie_type"), tmp );
                    
                }
            }
        }
        
        return genres;
    }
    
    /**
     * 
     * @param genres all genres
     * @param gen fix genre
     * @param month fix month
     * @return HashMap of genres as keys and the money for the month as values
     * @throws SQLException 
     */
    
    public static HashMap<String, Integer> MoM(HashMap<String, ArrayList<String>> genres,String gen, int month) throws SQLException{
        
       
        List<String> movienames = new ArrayList<>();
        List<Integer> money = new ArrayList<>();
        HashMap<String, Integer> pole = new HashMap<>();
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM screenings as s JOIN movies as m ON s.movie_id = m.id "
                        + "JOIN tickets as t ON t.screening_id = s.id JOIN prices as p ON t.price_id = p.id WHERE EXTRACT(MONTH FROM s.start_time) = "
                        + Integer.toString(month) )) {
                    try (ResultSet r = s.executeQuery()) {


                            while (r.next()) {
                                String title = r.getString("title");
                                if(genres.get(gen).contains(title)){
                                    if(movienames.contains(title)){
                                        int i = movienames.indexOf(r.getString("title"));
                                        money.set(i, money.get(i)+ Integer.parseInt(r.getString("price")));
                                    }
                                    else{
                                        movienames.add(r.getString("title"));
                                        money.add(Integer.parseInt(r.getString("price")));
                                    }
                                }

                            }
                            int alter = movienames.size();
                            for(int i = 0; i < alter && i < 3; i++){
                                int indexMax = money.indexOf(Collections.max(money));
                                String movienm = movienames.get(indexMax);

                                pole.put(movienm, money.get(indexMax));

                                money.remove(money.get(indexMax));
                                movienames.remove(movienames.get(indexMax));

                            }
                        }

                        
                        return pole;

                }
    }
    
}
