/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import app.DbContext;

/**
 *
 * @author David Demjen
 * cast kodu je na zaklade vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class PriceFinder {
    private static final PriceFinder INSTANCE = new PriceFinder();

    public static PriceFinder getInstance() {
        return INSTANCE;
    }

    private PriceFinder() {
    }

    public Price findById(int id) throws SQLException {

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM prices WHERE id = ?")) {
            s.setInt(1, id);

            try (ResultSet r = s.executeQuery()) {
                if (r.next()) {
                    Price c = new Price();

                    c.setId(r.getInt("id"));
                    c.setType(r.getString("type"));
                    c.setPrice(Integer.parseInt(r.getString("price")));
                    

                    if (r.next()) {
                        throw new RuntimeException("Move than one row was returned");
                    }

                    return c;
                } else {
                    return null;
                }
            }
        }
    }

    public List<Price> findAll() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM prices")) {
            try (ResultSet r = s.executeQuery()) {

                List<Price> elements = new ArrayList<>();

                while (r.next()) {
                   Price c = new Price();

                    c.setId(r.getInt("id"));
                    c.setType(r.getString("type"));
                    c.setPrice(Integer.parseInt(r.getString("price")));

                    elements.add(c);
                }

                return elements;
            }
        }
    }

}
