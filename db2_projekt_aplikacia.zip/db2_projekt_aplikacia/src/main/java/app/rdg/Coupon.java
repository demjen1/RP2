/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import app.DbContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Asus
 */
public class Coupon extends Entity{
    
    int discount;
    String code;
    Integer customer_id;
    boolean used;
    
    public void setCustomer(int id){
        customer_id = id;
    }
    
    public Integer getCustomer(){
        return customer_id;
    }
    
    public void setDiscount(int discount){
        this.discount = discount;
    }
    public int getDiscount(){
        return discount;
    }
    
    public void setCode(String code){
        this.code = code;
    }
    public String getCode(){
        return code;
    }
    
    public void setUsed(boolean used){
        this.used = used;
    }
    public boolean getUsed(){
        return used;
    }
    
    public void insertCoupon() throws SQLException{
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("INSERT INTO coupons (discount, code, customer_id, used) VALUES (?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            
            
          
            s.setInt(1, discount);
            s.setString(2, code);
            s.setInt(3, customer_id);
            s.setBoolean(4, used);
           

            s.executeUpdate();

            try (ResultSet r = s.getGeneratedKeys()) {
                r.next();
                id = r.getInt(1);
            }
        }
    }
    
    public void delete() throws SQLException {
        if (id == null) {
            throw new IllegalStateException("id is not set");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("DELETE FROM coupons WHERE id = ?")) {
            s.setInt(1, id);

            s.executeUpdate();
        }
    }
    
    public void update() throws SQLException {
        if (id == null) {
            throw new IllegalStateException("id is not set");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("UPDATE coupons SET discount = ?, code = ?, customer_id = ?, used = ? WHERE id = ?")) {
            s.setInt(1, discount);
            s.setString(2, code);
            s.setInt(3, customer_id);
            s.setBoolean(4, used);
            s.setInt(5, id);
            s.executeUpdate();
        }
    }
    
    
    public void print(){
         System.out.println("== " + Integer.toString(id) + " ==");
        System.out.println("Discount: " + Integer.toString(discount));
        System.out.println("Code: " + code);
        System.out.println("Used: " + Boolean.toString(used));
        System.out.println("Customer: " + Integer.toString(customer_id));
        System.out.println();
        
        
        
    }
    
}
