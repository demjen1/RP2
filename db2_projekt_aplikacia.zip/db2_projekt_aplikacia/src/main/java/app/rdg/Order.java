/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import app.DbContext;

/**
 *
 * @author David Demjen
 * cast kodu je zo vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class Order extends Entity {
    Timestamp order_time;
    Integer customer_id;
    Integer coupon_id;
    boolean closed;
    
    public Order(){
        
    }
    
    public boolean getClosed(){
        return closed;
    }
    
    public void setClosed(boolean clsd){
        closed = clsd;
    }
    
    public Integer getCoupon(){
        return coupon_id;
    }
    
    public void setCoupon(Integer cid){
        coupon_id = cid;
    }
    
    public Timestamp getOrderTime() {
        return order_time;
    }

    public void setOrderTime(Timestamp time) {
        this.order_time = time;
    }

    public Integer getCustomer() {
        return customer_id;
    }

    public void setCustomer(Integer lastName) {
        this.customer_id = lastName;
    }
    
    public void insert() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("INSERT INTO orders (order_time, customer_id, coupon_id, closed) VALUES (?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            Timestamp ts = order_time;
            s.setTimestamp(1, ts);
            s.setInt(2, customer_id);
            if(coupon_id == null){
                s.setNull(3,java.sql.Types.INTEGER );
            }else{
                s.setInt(3, coupon_id);
            }
            s.setBoolean(4, closed);
            s.executeUpdate();

            try (ResultSet r = s.getGeneratedKeys()) {
                r.next();
                id = r.getInt(1);
            }
        }
    }

    public void update() throws SQLException {
        if (id == null) {
            throw new IllegalStateException("id is not set");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("UPDATE orders SET order_time = ?, customer_id = ?, coupon_id = ?, closed = ? WHERE id = ?")) {
            s.setTimestamp(1, order_time);
            s.setInt(2, customer_id);
            if(coupon_id != null){
                s.setInt(3, coupon_id);}
            else{
                s.setNull(3, java.sql.Types.INTEGER);
            }
            s.setBoolean(4, closed);
            s.setInt(5, id);
            

            s.executeUpdate();
        }
    }

    public void delete() throws SQLException {
        if (id == null) {
            throw new IllegalStateException("id is not set");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("DELETE FROM orders WHERE id = ?")) {
            s.setInt(1, id);

            s.executeUpdate();
        }
    }
    
    public boolean equals(Order  other){
        return this.id == other.getId();
    }

    
    public void print(){
        System.out.println("== " + Integer.toString(id) + " ==");
        System.out.println("Time: " + order_time.toString());
        System.out.println("Customer ID: " + Integer.toString(customer_id));
        System.out.println();
       // printGenres();
    }
        
        
        
    
    
    
}
