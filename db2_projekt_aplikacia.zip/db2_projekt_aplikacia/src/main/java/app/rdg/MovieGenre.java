/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import app.DbContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Asus
 */
public class MovieGenre {
    Integer movie_id;
    Integer genre_id;
    
    public void setMovie(int movie) {
        this.movie_id = movie;
    }
    
    public void setGenre(int movie) {
        this.genre_id = movie;
    }
    
    public void insert() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("INSERT INTO moviegenres (movie_id, genre_id) VALUES (?,?)", Statement.RETURN_GENERATED_KEYS)) {
            s.setInt(1, movie_id);
            
            s.setInt(2, genre_id);

            s.executeUpdate();
/*
            try (ResultSet r = s.getGeneratedKeys()) {
                r.next();
                id = r.getInt(1);
            }*/
        }
    }

   

    public void delete() throws SQLException {
        if (genre_id == null) {
            throw new IllegalStateException("id is not set");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("DELETE FROM moviegenres WHERE genre_id = ? AND movie_id = ?")) {
            s.setInt(1, genre_id);
            s.setInt(2, movie_id);

            s.executeUpdate();
        }
    }
    
    
    
    
    
}
