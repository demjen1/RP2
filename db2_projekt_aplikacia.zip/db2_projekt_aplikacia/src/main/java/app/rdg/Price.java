/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

/**
 *
 * @author David Demjen
 * cast kodu je zo vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class Price extends Entity {
    String type;
    int price;
    
   
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int lastName) {
        this.price = lastName;
    }

    public void print(){
        
        System.out.println("== " + Integer.toString(id) + " ==");
        System.out.println(type + ": " + Integer.toString(price));
        System.out.println();
        
    }
}
