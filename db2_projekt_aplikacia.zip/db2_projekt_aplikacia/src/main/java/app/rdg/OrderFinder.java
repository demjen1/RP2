/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import app.DbContext;

/**
 *
 * @author David Demjen
 * cast kodu je zo vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class OrderFinder {
    private static final OrderFinder INSTANCE = new OrderFinder();

    public static OrderFinder getInstance() {
        return INSTANCE;
    }

    private OrderFinder() {
    }

    public Order findById(int id) throws SQLException {

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM orders WHERE id = ?")) {
            s.setInt(1, id);

            try (ResultSet r = s.executeQuery()) {
                if (r.next()) {
                    Order c = new Order();

                    c.setId(r.getInt("id"));
                    c.setOrderTime(r.getTimestamp("order_time"));
                    c.setCustomer(Integer.parseInt(r.getString("customer_id")));
                    Integer coup = r.getInt("coupon_id");
                    c.setClosed(r.getBoolean("closed"));
                    if(coup == 0 || coup == null){
                        c.setCoupon(null);

                    }
                    else{
                        c.setCoupon(coup);
                    }
                    
                    if (r.next()) {
                        throw new RuntimeException("Move than one row was returned");
                    }

                    return c;
                } else {
                    return null;
                }
            }
        }
    }

    public List<Order> findAll() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM orders")) {
            try (ResultSet r = s.executeQuery()) {

                List<Order> elements = new ArrayList<>();

                while (r.next()) {
                    Order c = new Order();

                    c.setId(r.getInt("id"));
                    c.setOrderTime(r.getTimestamp("order_time"));
                    c.setCustomer(Integer.parseInt(r.getString("customer_id")));
                    String coup = r.getString("coupon_id");
                    c.setClosed(r.getBoolean("closed"));
                    if(coup == null){
                        c.setCoupon(null);

                    }
                    else{
                        c.setCoupon(Integer.parseInt(coup));
                    }    
                    elements.add(c);
                }

                return elements;
            }
        }
    }
    
    public List<Order> findAllById(int id) throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM orders WHERE customer_id = " + Integer.toString(id))) {
            try (ResultSet r = s.executeQuery()) {

                List<Order> elements = new ArrayList<>();

                while (r.next()) {
                    Order c = new Order();

                    c.setId(r.getInt("id"));
                    c.setOrderTime(r.getTimestamp("order_time"));
                    c.setCustomer(Integer.parseInt(r.getString("customer_id")));
                    c.setClosed(r.getBoolean("closed"));
                    String coup = r.getString("coupon_id");
                    if(coup == null){
                        c.setCoupon(null);

                    }
                    else{
                        c.setCoupon(Integer.parseInt(coup));
                    }
                    elements.add(c);
                }

                return elements;
            }
        }
    }
    
    public List<Order> findAllNotClosed() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM orders WHERE closed = false")) {
            try (ResultSet r = s.executeQuery()) {

                List<Order> elements = new ArrayList<>();

                while (r.next()) {
                    Order c = new Order();

                    c.setId(r.getInt("id"));
                    c.setOrderTime(r.getTimestamp("order_time"));
                    c.setCustomer(Integer.parseInt(r.getString("customer_id")));
                    c.setClosed(r.getBoolean("closed"));
                    String coup = r.getString("coupon_id");
                    if(coup == null){
                        c.setCoupon(null);

                    }
                    else{
                        c.setCoupon(Integer.parseInt(coup));
                    }
                    elements.add(c);
                }

                return elements;
            }
        }
    }
    
    public List<Ticket> findTicketsForOrder(int id) throws SQLException{
        List<Ticket> ticks = new ArrayList<Ticket>();
        
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT t.id as id FROM orders as o LEFT JOIN tickets as t ON t.order_id = o.id WHERE o.id = " + Integer.toString(id))) {
            try (ResultSet r = s.executeQuery()) {


                while (r.next()) {
                    Ticket tmp = TicketFinder.getInstance().findById(r.getInt("id"));
                    
                    ticks.add(tmp);
                }

                return ticks;
            }
        }
        
        
       
    }
    
    
    
    
}
