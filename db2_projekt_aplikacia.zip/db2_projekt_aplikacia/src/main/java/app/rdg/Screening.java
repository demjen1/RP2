/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import app.DbContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;


/**
 *
 * @author David Demjen
 * cast kodu je na zaklade vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class Screening extends Entity{
    Timestamp start_time;
    Timestamp end_time;
    int hall_id;
    int movie_id;
    
    
    public int getHall() {
        return hall_id;
    }

    public void setHall(int firstName) {
        this.hall_id = firstName;
    }

    public int getMovie() {
        return movie_id;
    }

    public void setMovie(int lastName) {
        this.movie_id = lastName;
    }

    public Timestamp getStart() {
        return start_time;
    }

    public void setStart(Timestamp start) {
        this.start_time = start;
    }
    
    public Timestamp getEnd() {
        return end_time;
    }

    public void setEnd(Timestamp end) {
        this.end_time = end;
    }
    
    public void print(){
        System.out.println("== " + Integer.toString(id) + " ==");
        System.out.println("Start: " + start_time);
        System.out.println("Hall: " + Integer.toString(hall_id));
        
        System.out.println();
        
        
    }
    
    public void insert() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("INSERT INTO screenings (start_time, end_time, hall_id, movie_id) VALUES (?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            
            s.setTimestamp(1, start_time);
            s.setTimestamp(2, end_time);
            s.setInt(3, hall_id);
            s.setInt(4, movie_id);

            s.executeUpdate();

            try (ResultSet r = s.getGeneratedKeys()) {
                r.next();
                id = r.getInt(1);
            }
        }
    }
     public void delete() throws SQLException {
        if (id == null) {
            throw new IllegalStateException("id is not set");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("DELETE FROM screenings WHERE id = ?")) {
            s.setInt(1, id);

            s.executeUpdate();
        }
    }
    
}
