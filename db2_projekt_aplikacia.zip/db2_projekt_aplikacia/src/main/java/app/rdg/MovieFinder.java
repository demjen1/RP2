/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import app.DbContext;

/**
 *
 * @author David Demjen
 * cast kodu je zo vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class MovieFinder {
    private static final MovieFinder INSTANCE = new MovieFinder();

    public static MovieFinder getInstance() {
        return INSTANCE;
    }

    private MovieFinder() {
    }

    public Movie findById(int id) throws SQLException {

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM movies WHERE id = ?")) {
            s.setInt(1, id);

            try (ResultSet r = s.executeQuery()) {
                if (r.next()) {
                    Movie c = new Movie();

                    c.setId(r.getInt("id"));
                    c.setTitle(r.getString("title"));
                    c.setAgeLimit(Integer.parseInt(r.getString("age_limit")));
                    c.setRelease(Integer.parseInt(r.getString("release_date")));
                    

                    if (r.next()) {
                        throw new RuntimeException("Move than one row was returned");
                    }

                    return c;
                } else {
                    return null;
                }
            }
        }
    }

    public List<Movie> findAll() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM movies")) {
            try (ResultSet r = s.executeQuery()) {

                List<Movie> elements = new ArrayList<>();

                while (r.next()) {
                    Movie c = new Movie();

                    c.setId(r.getInt("id"));
                    c.setTitle(r.getString("title"));
                    c.setAgeLimit(Integer.parseInt(r.getString("age_limit")));
                    c.setRelease(Integer.parseInt(r.getString("release_date")));

                    elements.add(c);
                }

                return elements;
            }
        }
    }
    
    public ArrayList<String> getGenres(Movie movie) throws SQLException{
       ArrayList<String> pole = new ArrayList<String>();
       try(PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM movies as m LEFT JOIN moviegenres as x ON m.id = x.movie_id LEFT JOIN genres as g ON x.genre_id = g.id WHERE m.id = " + Integer.toString(movie.id))){
          try (ResultSet r = s.executeQuery()) {
              while(r.next()){
                  pole.add(r.getString("movie_type"));
                  
              }
              
              
          }
           
       }
       
       
       
       
       
       
       
       return pole;
    }

}
