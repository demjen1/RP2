/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import app.DbContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asus
 */
public class CouponFinder {
    private static final CouponFinder INSTANCE = new CouponFinder();

    public static CouponFinder getInstance() {
        return INSTANCE;
    }

    private CouponFinder() {
    }
    
    public List<Coupon> findAllById(int id) throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM coupons WHERE customer_id = " + Integer.toString(id))) {
            try (ResultSet r = s.executeQuery()) {

                List<Coupon> elements = new ArrayList<>();

                while (r.next()) {
                    Coupon c = new Coupon();

                    c.setId(r.getInt("id"));
                    c.setCode(r.getString("code"));
                    c.setCustomer(Integer.parseInt(r.getString("customer_id")));
                    c.setDiscount(Integer.parseInt(r.getString("discount")));
                    c.setUsed(r.getBoolean("used"));
                    elements.add(c);
                }

                return elements;
            }
        }
    }
    
    public Coupon findById(int id) throws SQLException {

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM coupons WHERE id = ?")) {
            s.setInt(1, id);

            try (ResultSet r = s.executeQuery()) {
                
                    
                if (r.next()) {
                    Coupon c = new Coupon();

                    c.setId(r.getInt("id"));
                    c.setCode(r.getString("code"));
                    
                    c.setCustomer(r.getInt("customer_id"));
                    c.setUsed(r.getBoolean("used"));
                    c.setDiscount(r.getInt("discount"));
                    

                    if (r.next()) {
                        throw new RuntimeException("Move than one row was returned");
                    }

                    return c;
                } else {
                    return null;
                }
            }
        }
    }
    
    public Coupon findByCode(String code) throws SQLException {

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM coupons WHERE code = ?")) {
            s.setString(1, code);

            try (ResultSet r = s.executeQuery()) {
                if (r.next()) {
                    Coupon c = new Coupon();

                    c.setId(r.getInt("id"));
                    c.setCode(r.getString("code"));
                    c.setCustomer(r.getInt("customer_id"));
                    c.setUsed(r.getBoolean("used"));
                    c.setDiscount(r.getInt("discount"));
                    
                    

                    if (r.next()) {
                        throw new RuntimeException("Move than one row was returned");
                    }

                    return c;
                } else {
                    return null;
                }
            }
        }
    }
    
}
