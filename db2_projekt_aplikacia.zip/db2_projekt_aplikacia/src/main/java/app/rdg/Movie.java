/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import app.DbContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author David Demjen
 * cast kodu je zo vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class Movie extends Entity{
    
    
    String title;
    int release;
    int age_limit;
    
    

    public String getTitle() {
        return title;
    }

    public void setTitle(String firstName) {
        this.title = firstName;
    }

    public int getAgeLimit() {
        return age_limit;
    }

    public void setAgeLimit(int lastName) {
        this.age_limit = lastName;
    }

    public int getRelease() {
        return release;
    }

    public void setRelease(int eMail) {
        this.release = eMail;
    }
    
    public void insert() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("INSERT INTO movies (title, age_limit, release_date) VALUES (?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            
            s.setString(1, title);
            s.setInt(2, age_limit);
            s.setInt(3, release);

            s.executeUpdate();

            try (ResultSet r = s.getGeneratedKeys()) {
                r.next();
                id = r.getInt(1);
            }
        }
    }

    public void update() throws SQLException {
        if (id == null) {
            throw new IllegalStateException("id is not set");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("UPDATE movies SET title = ?, age_limit = ?, release_date = ? WHERE id = ?")) {
            s.setString(1, title);
            s.setInt(3, release);
            s.setInt(2, age_limit);
            s.setInt(4, id);
            s.executeUpdate();
            
        }
    }

    public void delete() throws SQLException {
        if (id == null) {
            throw new IllegalStateException("id is not set");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("DELETE FROM movies WHERE id = ?")) {
            s.setInt(1, id);

            s.executeUpdate();
        }
    }
    
    public void print(){
        System.out.println("== " + Integer.toString(id) + " ==");
        System.out.println("Title: " + title);
        System.out.println("Age limit: " + Integer.toString(age_limit));
        System.out.println("Release date: " + release);
        System.out.println();
       // printGenres();
    }
    
    /*
    public void printGenres(){
        
    }
    */
}
