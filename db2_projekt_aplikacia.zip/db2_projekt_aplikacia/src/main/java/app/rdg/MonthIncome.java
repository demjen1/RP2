/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import app.DbContext;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Asus
 */
public class MonthIncome {
    private static final MonthIncome INSTANCE = new MonthIncome();

    /**
     *
     * @return
     */
    public static MonthIncome getInstance() {
        return INSTANCE;
    }

    private MonthIncome() {
    }
    
    /**
     *
     * @return HashMap<String,Integer[2]> from table with the income for every genre for this month and previous
     *         
     * @throws SQLException
     */
    public HashMap<String,Integer[]> monthIncome() throws SQLException{
        HashMap<String, Integer[]> out = new HashMap<>();
        
        String qry = "SELECT g.movie_type as genre, sum( CASE WHEN p.price IS NULL THEN 0 ELSE p.price END) as income "
                + "FROM genres as g LEFT JOIN moviegenres as mg ON g.id = mg.genre_id "
                + "LEFT JOIN movies as m ON mg.movie_id = m.id LEFT JOIN screenings as s ON s.movie_id = m.id "
                + "LEFT JOIN tickets as t ON s.id = t.screening_id LEFT JOIN prices as p ON p.id = t.price_id"
                + " WHERE date_part('month', s.start_time)::integer =date_part('month', CURRENT_DATE)::integer-0 OR s.start_time IS NULL "
                + "GROUP BY g.movie_type";
        
        
        String qry2 = "SELECT g.movie_type as genre, sum( CASE WHEN p.price IS NULL THEN 0 ELSE p.price END) as income "
                + "FROM genres as g LEFT JOIN moviegenres as mg ON g.id = mg.genre_id "
                + "LEFT JOIN movies as m ON mg.movie_id = m.id LEFT JOIN screenings as s ON s.movie_id = m.id "
                + "LEFT JOIN tickets as t ON s.id = t.screening_id LEFT JOIN prices as p ON p.id = t.price_id"
                + " WHERE date_part('month', s.start_time)::integer =date_part('month', CURRENT_DATE)::integer-1 OR s.start_time IS NULL "
                + "GROUP BY g.movie_type";
        
        String qryfin = "SELECT a.genre as genre, a.income as last_month, b.income as pre_last_month"
                + " FROM (" + qry+") as a LEFT JOIN (" + qry2 +") as b ON a.genre = b.genre ";
        
        Connection connection = DbContext.getConnection();
        Statement st = DbContext.getConnection().createStatement();
        ResultSet rs = st.executeQuery(qryfin);
        
        while(rs.next()){
            Integer[] tmp = new Integer[2];
            tmp[0] = rs.getInt("last_month");
            tmp[1] = rs.getInt("pre_last_month");
            out.put(rs.getString("genre"), tmp);
        }
        
       
        return out;
    }
    
    
    
    
}
