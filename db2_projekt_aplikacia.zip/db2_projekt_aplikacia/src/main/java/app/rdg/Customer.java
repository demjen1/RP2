package app.rdg;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import app.DbContext;
import java.sql.Timestamp;

/**
 *
 * @author David Demjen
 * cast kodu je zo vzoroveho projektu: Author: Alexander Šimko
 * 
 */

public class Customer extends Entity{

    private String firstName;
    private String lastName;
    private String e_mail;
    private String birth;

   

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return e_mail;
    }

    public void setEmail(String eMail) {
        this.e_mail = eMail;
    }

    public String getBirth() {
        return birth;
    }

    public void setBirth(String address) {
        this.birth = address;
    }

    public void insert() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("INSERT INTO customers (first_name, last_name, e_mail, birth) VALUES (?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            s.setString(1, firstName);
            s.setString(2, lastName);
            s.setString(3, e_mail);
            s.setString(4, birth);
            //s.setTimestamp(4, Timestamp.valueOf(birth));

            s.executeUpdate();

            try (ResultSet r = s.getGeneratedKeys()) {
                r.next();
                id = r.getInt(1);
            }
        }
    }

    public void update() throws SQLException {
        if (id == null) {
            throw new IllegalStateException("id is not set");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("UPDATE customers SET first_name = ?, last_name = ?, e_mail = ?, birth = ? WHERE id = ?")) {
            s.setString(1, firstName);
            s.setString(2, lastName);
            s.setString(3, e_mail);
            s.setString(4, birth);
            s.setInt(5, id);

            s.executeUpdate();
        }
    }

    public void delete() throws SQLException {
        if (id == null) {
            throw new IllegalStateException("id is not set");
        }

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("DELETE FROM customers WHERE id = ?")) {
            s.setInt(1, id);

            s.executeUpdate();
        }
    }

}
