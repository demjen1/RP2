package app.rdg;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import app.DbContext;

/**
 *
 * @author David Demjen
 * cast kodu je zo vzoroveho projektu: Author: Alexander Šimko
 * 
 */

public class CustomerFinder {

    private static final CustomerFinder INSTANCE = new CustomerFinder();

    public static CustomerFinder getInstance() {
        return INSTANCE;
    }

    private CustomerFinder() {
    }

    public Customer findById(int id) throws SQLException {

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM customers WHERE id = ?")) {
            s.setInt(1, id);

            try (ResultSet r = s.executeQuery()) {
                if (r.next()) {
                    Customer c = new Customer();

                    c.setId(r.getInt("id"));
                    c.setFirstName(r.getString("first_name"));
                    c.setLastName(r.getString("last_name"));
                    c.setEmail(r.getString("e_mail"));
                    c.setBirth(r.getString("birth"));

                    if (r.next()) {
                        throw new RuntimeException("Move than one row was returned");
                    }

                    return c;
                } else {
                    return null;
                }
            }
        }
    }

    public List<Customer> findAll() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM customers")) {
            try (ResultSet r = s.executeQuery()) {

                List<Customer> elements = new ArrayList<>();

                while (r.next()) {
                    Customer c = new Customer();

                    c.setId(r.getInt("id"));
                    c.setFirstName(r.getString("first_name"));
                    c.setLastName(r.getString("last_name"));
                    c.setEmail(r.getString("e_mail"));
                    c.setBirth(r.getString("birth"));

                    elements.add(c);
                }

                return elements;
            }
        }
    }

}
