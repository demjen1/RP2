/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import app.DbContext;
import java.sql.Timestamp;

/**
 *
 * @author David Demjen
 * cast kodu je na zaklade vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class ScreeningFinder {
    private static final ScreeningFinder INSTANCE = new ScreeningFinder();

    public static ScreeningFinder getInstance() {
        return INSTANCE;
    }

    private ScreeningFinder() {
    }

    public Screening findById(int id) throws SQLException {

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM screenings WHERE id = ?")) {
            s.setInt(1, id);

            try (ResultSet r = s.executeQuery()) {
                if (r.next()) {
                    Screening c = new Screening();

                    c.setId(r.getInt("id"));
                    c.setStart(r.getTimestamp("start_time"));
                    c.setMovie(Integer.parseInt(r.getString("movie_id")));
                    c.setHall(Integer.parseInt(r.getString("hall_id")));
                    c.setEnd(r.getTimestamp("end_time"));
                    
                    

                    if (r.next()) {
                        throw new RuntimeException("Move than one row was returned");
                    }

                    return c;
                } else {
                    return null;
                }
            }
        }
    }
    
    

    public List<Screening> findAll() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM screenings")) {
            try (ResultSet r = s.executeQuery()) {

                List<Screening> elements = new ArrayList<>();

                while (r.next()) {
                    Screening c = new Screening();

                    c.setId(r.getInt("id"));
                    c.setStart(r.getTimestamp("start_time"));
                    c.setMovie(Integer.parseInt(r.getString("movie_id")));
                    c.setHall(Integer.parseInt(r.getString("hall_id")));
                    c.setEnd(r.getTimestamp("end_time"));

                    elements.add(c);
                }

                return elements;
            }
        }
    }
    
    public List<Screening> findForMovie(Movie movie) throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM screenings WHERE movie_id = " + Integer.toString(movie.getId()))) {
            try (ResultSet r = s.executeQuery()) {

                List<Screening> elements = new ArrayList<>();

                while (r.next()) {
                    Screening c = new Screening();

                    c.setId(r.getInt("id"));
                    c.setStart(r.getTimestamp("start_time"));
                    c.setMovie(Integer.parseInt(r.getString("movie_id")));
                    c.setHall(Integer.parseInt(r.getString("hall_id")));
                    c.setEnd(r.getTimestamp("end_time"));

                    elements.add(c);
                }

                return elements;
            }
        }
    }
    
    public List<Screening> findForMovie(Movie movie, Timestamp current) throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM screenings WHERE movie_id = " + Integer.toString(movie.getId()))) {
            try (ResultSet r = s.executeQuery()) {

                List<Screening> elements = new ArrayList<>();

                while (r.next()) {
                    Screening c = new Screening();

                    c.setId(r.getInt("id"));
                    c.setStart(r.getTimestamp("start_time"));
                    c.setMovie(Integer.parseInt(r.getString("movie_id")));
                    c.setHall(Integer.parseInt(r.getString("hall_id")));
                    c.setEnd(r.getTimestamp("end_time"));
                    if(2400000 < c.getStart().getTime() - current.getTime() ){
                        elements.add(c);
                    }
                    
                }

                return elements;
            }
        }
    }
    
    public Integer getHallSeats(Integer screening_id) throws SQLException{
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM halls WHERE id = " + Integer.toString(screening_id))) {
            try (ResultSet r = s.executeQuery()) {

                if(r.next()){
                    return r.getInt("seat_count");
                }
                else{
                    return 0;
                }
            }
        }
        
        
    

}
}