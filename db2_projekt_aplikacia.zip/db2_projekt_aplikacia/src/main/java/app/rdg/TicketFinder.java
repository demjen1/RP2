/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.rdg;

import app.DbContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asus
 */
public class TicketFinder {
    
    private static final TicketFinder INSTANCE = new TicketFinder();

    public static TicketFinder getInstance() {
        return INSTANCE;
    }

    private TicketFinder() {
    }
    
    public Ticket findById(int id) throws SQLException {

        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM tickets WHERE id = ?")) {
            s.setInt(1, id);

            try (ResultSet r = s.executeQuery()) {
                if (r.next()) {
                    Ticket c = new Ticket();

                    c.setId(r.getInt("id"));
                    c.setOrder(r.getInt("order_id"));
                    c.setPrice(r.getInt("price_id"));
                    c.setScreening(r.getInt("screening_id"));
                    c.setrow(r.getInt("row_number"));
                    c.setseat(r.getInt("seat_number"));

                    if (r.next()) {
                        throw new RuntimeException("Move than one row was returned");
                    }

                    return c;
                } else {
                    return null;
                }
            }
        }
    }

    
    public List<Ticket> findAll() throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM tickets")) {
            try (ResultSet r = s.executeQuery()) {

                List<Ticket> elements = new ArrayList<>();

                while (r.next()) {
                    Ticket c = new Ticket();

                    c.setId(r.getInt("id"));
                    c.setOrder(Integer.parseInt(r.getString("order_id")));
                    c.setPrice(Integer.parseInt(r.getString("price_id")));
                    c.setScreening(Integer.parseInt(r.getString("sceening_id")));
                    c.setseat(Integer.parseInt(r.getString("seat_number")));
                    c.setrow(Integer.parseInt(r.getString("row_number")));

                    elements.add(c);
                }

                return elements;
            }
        }
    }
    public Integer countTicketsByScreening(int screen_id) throws SQLException {
        try (PreparedStatement s = DbContext.getConnection().prepareStatement("SELECT * FROM tickets WHERE screening_id = " + Integer.toString(screen_id))) {
            try (ResultSet r = s.executeQuery()) {

                Integer count = 0;
                while (r.next()) {
                    count++;
                }

                return count;
            }
        }
    }
}
