package app;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import org.postgresql.ds.PGSimpleDataSource;
import app.ui.MainMenu;

/**
 *
 * @author David Demjen
 * cast kodu je zo vzoroveho projektu: Author: Alexander Šimko
 * 
 */
public class Main {

    public static void main(String[] args) throws SQLException, IOException {

        PGSimpleDataSource dataSource = new PGSimpleDataSource();

        dataSource.setServerName("db.dai.fmph.uniba.sk");
        dataSource.setPortNumber(5432);
        dataSource.setDatabaseName("playground");
        dataSource.setUser("demjen1@uniba.sk");
        dataSource.setPassword("db2pwrd");

        try (Connection connection = dataSource.getConnection()) {
            DbContext.setConnection(connection);
            OrderController ordcont = new OrderController();
            MainMenu mainMenu = new MainMenu();
            ordcont.start();
            
            mainMenu.run();
            
            ordcont.runing = false;
            ordcont.interrupt();

        } finally {
            DbContext.clear();
        }
    }
}
