/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.ts;

import app.ex.CommonException;
import app.DbContext;
import app.ex.OutOfSeatsException;
import app.rdg.Coupon;
import app.rdg.CouponFinder;
import app.rdg.Customer;
import app.rdg.CustomerFinder;
import app.rdg.Movie;
import app.rdg.MovieFinder;
import app.rdg.Order;
import app.rdg.OrderFinder;
import app.rdg.Price;
import app.rdg.PriceFinder;
import app.rdg.Screening;
import app.rdg.ScreeningFinder;
import app.rdg.Ticket;
import app.rdg.TicketFinder;
import app.ui.MainMenu;
import static app.ui.MainMenu.isInteger;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import org.postgresql.util.PSQLException;

/**
 *
 * @author Asus
 */
public class OrderHandler {
    /**
     * 
     * @param tick - ticket to control
     * @return returns true if ticket can be bought
     * @throws SQLException 
     */
    
    public static boolean controlTicket(Ticket tick) throws SQLException{
        Screening c = ScreeningFinder.getInstance().findById(tick.getScreening());
        
        Integer seatcount = ScreeningFinder.getInstance().getHallSeats(c.getHall());
        Integer ticketcount = TicketFinder.getInstance().countTicketsByScreening(tick.getScreening());
        
        if(ticketcount>= seatcount){
            return false;
        }
        
         Timestamp current = new Timestamp(System.currentTimeMillis());
        if(2400000 > c.getStart().getTime() - current.getTime()) {
            return false;
        }
        
        
        return true;
    }
    
    /**
     * 
     * @param tick
     * @return same as controlTicket() , just doesnt controls time
     * @throws SQLException 
     */
    
    public static boolean controlTicketOutOfTime(Ticket tick) throws SQLException{
        Screening c = ScreeningFinder.getInstance().findById(tick.getScreening());
        
        Integer seatcount = ScreeningFinder.getInstance().getHallSeats(c.getHall());
        Integer ticketcount = TicketFinder.getInstance().countTicketsByScreening(tick.getScreening());
        
        if(ticketcount>= seatcount){
            return false;
        }
        
        return true;
    }
    
    /**
     * 
     * @param cust_id customer_id
     * @param tickets to reserve
     * @param code coupon code
     * @return List of tickets that couldnt been reserved
     * @throws SQLException 
     */
    public static List<Ticket> finishOrder(int cust_id, List<Ticket> tickets, String code) throws SQLException{
       
        List<Ticket> cant = new ArrayList<>();
         
        
                Order ord = new Order();
                ord.setCustomer(cust_id);
                Timestamp s = new Timestamp(System.currentTimeMillis());
                ord.setOrderTime(s);
                if(code != null){
                    Coupon coup = CouponFinder.getInstance().findByCode(code);
                    System.out.println(coup.getCustomer());
                    if(coup!= null && (coup.getCustomer() == cust_id || coup.getCustomer() == 0)){
                        coup.setCustomer(cust_id);
                        coup.setUsed(true);
                        coup.update();
                        ord.setCoupon(coup.getId());
                    }
                    else{
                        DbContext.getConnection().rollback();
                        return cant;
                    }
                }
                ord.insert();
                
                
                int cnt = 0;
                
                for(int i = 0; i < tickets.size(); i++){
                    tickets.get(i).delete();
                    if(controlTicket(tickets.get(i))){
                        cnt++;
                        
                        tickets.get(i).setOrder(ord.getId());
                        tickets.get(i).insertTicket();
                    }
                    else{
                        cant.add(tickets.get(i));
                        tickets.get(i).print();
                    }
                }
                if(cnt < 1){
                    
                    ord.delete();
                }
                
                
       return cant;
        
    }
    /**
     * 
     * @param x - ticket count
     * @param tickets - puts reserved tickets to this List
     * @param screening 
     * @param prc - price
     * @throws SQLException
     * @throws OutOfSeatsException
     */
    public static void reserveTickets(int x , List<Ticket> tickets, Screening screening, Price prc) throws SQLException, OutOfSeatsException{
        for(int i = 0; i < x; i++){
                Ticket tmpticket = new Ticket(screening.getId(), prc.getId());

                if(OrderHandler.controlTicket(tmpticket)){
                    tmpticket.insertTicketNullOrd();
                }else{
                    throw new OutOfSeatsException("Not enough space in the hall");
                }
                tickets.add(tmpticket);
                }
            
                
    }
    
    /**
     * 
     * @param x - ticket count
     * @param tickets - puts reserved tickets to this List
     * @param screening 
     * @param prc - price
     * @param order - order
     * @throws SQLException
     * @throws OutOfSeatsException 
     */
    
    public static void reserveTickets(int x , List<Ticket> tickets, Screening screening, Price prc, Order order) throws SQLException, OutOfSeatsException{
        for(int i = 0; i < x; i++){
                Ticket tmpticket = new Ticket(screening.getId(), prc.getId());
                System.out.println(order.getId());
                tmpticket.setOrder(order.getId());
                if(OrderHandler.controlTicket(tmpticket)){
                    tmpticket.insertTicket();
                }else{
                    throw new OutOfSeatsException("Not enough space in the hall or too late to buy a ticket");
                }
                tickets.add(tmpticket);
                }
            
                
    }
    
    /**
     * Makes the transaction script and confirms order, not using this
     * @throws SQLException
     * @throws IOException
     * @throws CommonException 
     */
    /*
    public static void order() throws SQLException, IOException, CommonException{
        long start = System.currentTimeMillis();
        DbContext.getConnection().setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
        DbContext.getConnection().setAutoCommit(false);
        try{
            MainMenu.makeOrder();
            long end = System.currentTimeMillis();
            if(end - start > 600000){
                throw new CommonException("Out of time");
            }
            
            
        }catch(SQLException | NullPointerException e){
            DbContext.getConnection().rollback();
            System.out.println(e.getMessage());
        }catch(CommonException e){
            DbContext.getConnection().rollback();
            System.out.println(e.getMessage());
            throw e;
        }catch(IOException e){
            DbContext.getConnection().rollback();
            throw e;
        }catch(OutOfSeatsException e){
            DbContext.getConnection().rollback();
            System.out.println(e.getMessage());
        }
        finally{
            DbContext.getConnection().setAutoCommit(true);
        }
        DbContext.getConnection().setAutoCommit(true);
        
        
    }*/
    
    /**
     * closes order
     * @param order
     * @throws SQLException 
     */
    
    private static void confirm(Order order) throws SQLException{
        order.setClosed(true);
        order.update();
    }
    
    /**
     * makes transaction script for the order isolation
     * @throws SQLException
     * @throws IOException
     * @throws OutOfSeatsException
     * @throws CommonException 
     */
    public static void order2() throws SQLException, IOException, OutOfSeatsException, CommonException{
        long start = System.currentTimeMillis();
        DbContext.getConnection().setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
        DbContext.getConnection().setAutoCommit(false);
        try{
            Order order = MainMenu.makeOrder2();
            if(order != null){
                long end = System.currentTimeMillis();
                if(end - start > 600000){
                    throw new CommonException("Out of time");
                }
                confirm(order);
            }
            
        }catch(SQLException | NullPointerException e){
            DbContext.getConnection().rollback();
            throw e;
        }catch(CommonException e){
            DbContext.getConnection().rollback();
            throw e;
            
        }catch(IOException e){
            DbContext.getConnection().rollback();
            throw e;
        }catch(OutOfSeatsException e){
            DbContext.getConnection().rollback();
            throw e;
        }
        
        finally{
            DbContext.getConnection().setAutoCommit(true);
        }
        
    }
    /**
     * inserts the order to the database
     * @param order order to insert
     * @param coup if coupon was used
     * @param customerId customer ID 
     * @param coupcode the code of the coupon
     * @throws SQLException
     * @throws CommonException 
     */
    public static void setOrder(Order order, boolean coup, int customerId, String coupcode) throws SQLException, CommonException{
        order.setOrderTime(new Timestamp(System.currentTimeMillis()));
        order.setCustomer(customerId);
        order.setClosed(false);
        if(coup){
            Coupon coupon = CouponFinder.getInstance().findByCode(coupcode);
            if(coupon.getCustomer() == customerId && !coupon.getUsed()){
                order.setCoupon(coupon.getId());}
            else{
                order.insert();
                throw new CommonException("The coupon cant be used, order added without coupon");
            }
        }
        order.insert();
    }
    
    
    
    
}